<footer class="footer footer-transparent d-print-none">
    <div class="container-xl">
        <div class="row text-center align-items-center flex-row-reverse">
            <div class="col-lg-auto ms-lg-auto">
                <ul class="list-inline list-inline-dots mb-0">

                    <li class="list-inline-item"><a href="" target="_blank"
                            class="link-secondary" rel="noopener">UTS - Muhammad Angga Sabima</a></li>

                </ul>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\uts_angga\resources\views/layouts/footer.blade.php ENDPATH**/ ?>